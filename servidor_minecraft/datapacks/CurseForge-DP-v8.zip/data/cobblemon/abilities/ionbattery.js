{
 onModifySpAPriority: 5,
      onModifySpA(spa, pokemon) {
        this.debug("Ion battery spa boost");
        return this.chainModify([3, 2]);
      },
	flags: {},
	name: "Ionbattery",
	rating: 4.5,
	num: 1466
}
